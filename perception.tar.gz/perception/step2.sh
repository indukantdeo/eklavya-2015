cd ~/catkin_ws/src/eklavya-2015/perception/lane_detector/data/
rosrun lane_detector svmTrain bcd #Enter the name of file of output from generate samples in 
													#place of "Training_file_name"
cd ../launch/
gedit module.launch
