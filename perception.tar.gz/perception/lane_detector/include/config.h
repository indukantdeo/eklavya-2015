#ifndef CONFIG_H
#define CONFIG_H

#include <iostream>

std::string getDataPath() {
    std::string path = "";
    return path;
}

#endif
