cd ~/catkin_ws/src/eklavya-2015/perception/lane_detector/data/
rosrun lane_detector generateSamples Test2.png #put in name of the image to train in place of "Test1.png"
